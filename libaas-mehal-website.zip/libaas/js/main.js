/* LIBAAS MEHAL — site interactions */
document.addEventListener('DOMContentLoaded', () => {

  /* Sticky header shadow */
  const header = document.querySelector('.site-header');
  if(header){
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 12);
    });
  }

  /* Mobile nav burger -> simple toggle (shows nav as block) */
  const burger = document.querySelector('.burger');
  const mainNav = document.querySelector('.main-nav');
  if(burger && mainNav){
    burger.addEventListener('click', () => {
      const open = mainNav.classList.toggle('mobile-open');
      mainNav.style.display = open ? 'flex' : 'none';
      mainNav.style.flexDirection = 'column';
      mainNav.style.position='absolute';
      mainNav.style.top='100%'; mainNav.style.left='0'; mainNav.style.right='0';
      mainNav.style.background='#fff';
      mainNav.style.padding='20px 6vw';
      mainNav.style.boxShadow='0 16px 30px rgba(0,0,0,.08)';
    });
  }

  /* Scroll reveal */
  const revealEls = document.querySelectorAll('.reveal, .reveal-stagger');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); obs.unobserve(e.target); } });
  }, { threshold: 0.15 });
  revealEls.forEach(el => obs.observe(el));

  /* Hero slider */
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.hero-dots button');
  let current = 0;
  if(slides.length){
    setInterval(() => {
      slides[current].classList.remove('active');
      dots[current] && dots[current].classList.remove('active');
      current = (current + 1) % slides.length;
      slides[current].classList.add('active');
      dots[current] && dots[current].classList.add('active');
    }, 5500);
    dots.forEach((d, i) => d.addEventListener('click', () => {
      slides[current].classList.remove('active'); dots[current].classList.remove('active');
      current = i;
      slides[current].classList.add('active'); dots[current].classList.add('active');
    }));
  }

  /* Product tabs filter (home / shop) */
  document.querySelectorAll('.tabs').forEach(tabGroup => {
    const buttons = tabGroup.querySelectorAll('button');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = tabGroup.dataset.target;
        const grid = document.querySelector(target);
        if(!grid) return;
        const filter = btn.dataset.filter;
        grid.querySelectorAll('.product-card').forEach(card => {
          card.style.display = (filter === 'all' || card.dataset.cat === filter) ? '' : 'none';
        });
      });
    });
  });

  /* Wishlist / cart count (local, just visual demo) */
  let wishlistCount = 0, cartCount = 0;
  const wishBadge = document.querySelector('#wishlistCount');
  const cartBadge = document.querySelector('#cartCount');
  document.querySelectorAll('.js-wishlist').forEach(btn => {
    btn.addEventListener('click', () => {
      wishlistCount++;
      if(wishBadge) wishBadge.textContent = wishlistCount;
      btn.classList.add('active');
      pulse(btn);
    });
  });
  document.querySelectorAll('.js-addcart').forEach(btn => {
    btn.addEventListener('click', () => {
      cartCount++;
      if(cartBadge) cartBadge.textContent = cartCount;
      pulse(btn);
    });
  });
  function pulse(el){
    el.style.transform = 'scale(1.25)';
    setTimeout(() => el.style.transform = '', 220);
  }

  /* Quantity selector */
  document.querySelectorAll('.qty-row').forEach(row => {
    const span = row.querySelector('span');
    let qty = 1;
    row.querySelector('.qty-minus').addEventListener('click', () => { qty = Math.max(1, qty - 1); span.textContent = qty; });
    row.querySelector('.qty-plus').addEventListener('click', () => { qty++; span.textContent = qty; });
  });

  /* Size selector */
  document.querySelectorAll('.size-row').forEach(row => {
    row.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        row.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });

  /* Gallery thumbs */
  document.querySelectorAll('.pd-thumbs').forEach(thumbs => {
    const main = document.querySelector('.pd-gallery-main img');
    thumbs.querySelectorAll('img').forEach(t => {
      t.addEventListener('click', () => {
        thumbs.querySelectorAll('img').forEach(x => x.classList.remove('active'));
        t.classList.add('active');
        if(main) main.src = t.src;
      });
    });
  });

  /* Accordion */
  document.querySelectorAll('.accordion-item .acc-head').forEach(head => {
    head.addEventListener('click', () => {
      const item = head.closest('.accordion-item');
      const body = item.querySelector('.acc-body');
      const isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.accordion-item').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.acc-body').style.maxHeight = null;
      });
      if(!isOpen){
        item.classList.add('open');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

  /* Back to top */
  const totop = document.querySelector('.fab.totop');
  if(totop){
    window.addEventListener('scroll', () => totop.classList.toggle('show', window.scrollY > 500));
    totop.addEventListener('click', () => window.scrollTo({ top:0, behavior:'smooth' }));
  }

  /* Newsletter form demo */
  document.querySelectorAll('.news-form, .form-luxury').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit], button');
      if(btn){ const original = btn.textContent; btn.textContent = 'Thank you ✓'; setTimeout(() => btn.textContent = original, 2400); }
    });
  });

});
